from metro_predictor import MetroPredictor

metro_predictor = MetroPredictor(grayscale=False, recognition_time=0.5)

metro_predictor.start_process()
